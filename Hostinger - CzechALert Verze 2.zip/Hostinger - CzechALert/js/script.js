
const nav = document.querySelector(".nav");
const navMenu = document.querySelector(".nav--menu");
const hamburger = document.querySelector(".nav--hamburger");
const navLinks = document.querySelectorAll(".nav--link");

// Helper function to open the menu
const openMenu = () => {
    navMenu.classList.add("open");
    nav.classList.add("open");
    hamburger.classList.add("is-active");
}

// Helper function to close the menu
const closeMenu = () => {
    navMenu.classList.add("closing"); // Start closing animation
    navMenu.addEventListener(
        "animationend",
        () => {
            navMenu.classList.remove("open", "closing"); // Reset classes after animation
            nav.classList.remove("open");
            hamburger.classList.remove("is-active");
        },
        { once: true }
    );
};

// Toggle menu on hamburger click
hamburger.addEventListener("click", () => {
    if (navMenu.classList.contains("open")) {
        closeMenu(); // If open, close it
    } else {
        openMenu(); // If closed, open it
    }
});

// Close menu on link click
navLinks.forEach((link) => {
    link.addEventListener("click", closeMenu);
});



